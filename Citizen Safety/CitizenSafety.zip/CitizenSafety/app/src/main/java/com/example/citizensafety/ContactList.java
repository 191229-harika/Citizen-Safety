package com.example.citizensafety;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.CursorAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ContactList extends AppCompatActivity {
    ListView listView;
    DbHelper db;
    List<ContactModel> list;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contactlist);
        listView = (ListView) findViewById(R.id.ListView);
        db = new DbHelper(this);
        list = db.getAllContacts();
        customAdapter = new CustomAdapter(this, R.layout.contactlist, R.id.ListView, list);
        listView.setAdapter(customAdapter);
        list = db.getAllContacts();
        customAdapter.refresh(list);
            }
        }


