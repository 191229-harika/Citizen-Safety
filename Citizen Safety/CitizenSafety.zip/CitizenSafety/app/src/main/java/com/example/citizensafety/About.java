package com.example.citizensafety;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class About extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
        TextView txt = (TextView)findViewById(R.id.textView2);
        Intent i = getIntent();
        txt.setText("In Emergency Shake your mobile for 4 times,then  message will be sent to your Emergency contacts with GPS if Location is ON else, only a message requesting for help is sent.\n\nNote: After shaking the mobile for 2 times it will send a notification for your mobile and vibrates,if not in Emergency stop shaking your phone.");
        Button b = (Button)findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(About.this,MainActivity.class);
                //i1.putExtra("number",(String)mListView.getAdapter().getItem(i));
                startActivity(i1);
            }
        });
    }
}
